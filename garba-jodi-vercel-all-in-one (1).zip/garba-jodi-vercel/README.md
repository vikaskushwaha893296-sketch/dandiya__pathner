# Garba Jodi – All-in-one (Vercel)
Frontend (`public/`) + backend (`server.js`) ek hi Vercel project mein.

## Deploy
1. Folder ko GitHub repo mein upload karo.
2. vercel.com → Add New → Project → repo import (settings waisi hi rehne do).
3. Project → Storage → **Neon Postgres** connect karo (`DATABASE_URL` apne aap aata hai).
4. Settings → Environment Variables → `JWT_SECRET` = lamba random text (16+ chars).
5. Deploy / Redeploy. `/api/health` kholo → `{"ok":true}`.

Purane deploy par update ho raha ho toh bas naye files push karo; naye tables/columns apne aap ban jaate hain.

## Features
Landing page, login/register (18+), profile menu, photo upload, profile (age, gender, state, city, area),
filters + sort (mere sheher ke pehle), profile popup, chat + unread badge, block, report,
settings (password change, account delete), safety tips.

## Abhi nahi hai
Email verification, password reset, unblock list, admin panel for reports, real-time chat (WebSocket), events listing.
Live karne se pehle Terms/Privacy pages bhi (legal review ke saath) add karo.
