require('dotenv').config();
const express = require('express'), cors = require('cors'), helmet = require('helmet');
const rateLimit = require('express-rate-limit'), bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken'), { Pool, types } = require('pg');

const SECRET = process.env.JWT_SECRET;
if (!SECRET || SECRET.length < 16) throw new Error('JWT_SECRET (16+ chars) set karo');
if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL set karo');

types.setTypeParser(20, v => parseInt(v, 10)); // bigint -> number
const pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 3 });
const q = (sql, p) => pool.query(sql, p);

const SCHEMA = `
create table if not exists users(id serial primary key, email text unique not null, pass text not null, created bigint);
create table if not exists profiles(user_id integer primary key references users(id), name text, age integer, gender text,
  state text, city text, area text, style text, level text, want text, venue text, bio text, photo text, updated bigint);
create table if not exists messages(id serial primary key, from_id integer not null, to_id integer not null, text text not null,
  sent_at bigint not null, seen boolean not null default false);
create table if not exists blocks(blocker integer not null, blocked integer not null, primary key(blocker, blocked));
create table if not exists reports(id serial primary key, reporter integer, reported integer, reason text, sent_at bigint);
alter table profiles add column if not exists photo text;
alter table messages add column if not exists seen boolean not null default false;
create index if not exists msg_from on messages(from_id, sent_at);
create index if not exists msg_to on messages(to_id, sent_at);`;
let ready;
const init = () => ready || (ready = q(SCHEMA).catch(e => { ready = null; throw e; }));

const ENUM = {
  gender: ['Male', 'Female', 'Other'], style: ['Dandiya', 'Garba', 'Dono'],
  level: ['Beginner', 'Intermediate', 'Pro'], want: ['Koi bhi', 'Ladki partner', 'Ladka partner', 'Group']
};
const str = (v, n) => String(v == null ? '' : v).trim().slice(0, n);
const sign = id => jwt.sign({ id }, SECRET, { expiresIn: '30d' });
const wrap = fn => (req, res, next) => Promise.resolve(fn(req, res)).catch(next);
const auth = (req, res, next) => {
  try { req.uid = jwt.verify((req.headers.authorization || '').replace('Bearer ', ''), SECRET).id; next(); }
  catch { res.status(401).json({ error: 'Login karo' }); }
};
const isBlocked = async (a, b) => (await q('select 1 from blocks where (blocker=$1 and blocked=$2) or (blocker=$2 and blocked=$1)', [a, b])).rowCount > 0;
const NOT_BLOCKED = 'user_id not in (select blocked from blocks where blocker=$1) and user_id not in (select blocker from blocks where blocked=$1)';

const app = express();
app.set('trust proxy', 1);
app.use(helmet());
if (process.env.FRONTEND_ORIGIN) app.use(cors({ origin: process.env.FRONTEND_ORIGIN.split(',').map(s => s.trim()) }));
app.use(express.json({ limit: '120kb' }));
// Note: serverless mein yeh limits har instance ke hisaab se lagti hain
app.use('/api', rateLimit({ windowMs: 60000, limit: 300 }));
const authLimit = rateLimit({ windowMs: 15 * 60000, limit: 30, message: { error: 'Bahut attempts, thodi der baad try karo' } });
app.use((req, res, next) => init().then(() => next(), next));

app.get('/api/health', (req, res) => res.json({ ok: true }));

app.post('/api/register', authLimit, wrap(async (req, res) => {
  const email = str(req.body.email, 100).toLowerCase(), pw = String(req.body.password || '');
  if (!/^\S+@\S+\.\S+$/.test(email) || pw.length < 8 || pw.length > 72)
    return res.status(400).json({ error: 'Sahi email aur 8+ character ka password do' });
  try {
    const r = await q('insert into users(email,pass,created) values($1,$2,$3) returning id', [email, bcrypt.hashSync(pw, 10), Date.now()]);
    res.json({ token: sign(r.rows[0].id) });
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ error: 'Yeh email pehle se registered hai' });
    throw e;
  }
}));

app.post('/api/login', authLimit, wrap(async (req, res) => {
  const u = (await q('select * from users where email=$1', [str(req.body.email, 100).toLowerCase()])).rows[0];
  if (!u || !bcrypt.compareSync(String(req.body.password || ''), u.pass))
    return res.status(401).json({ error: 'Email ya password galat hai' });
  res.json({ token: sign(u.id) });
}));

app.get('/api/me', auth, wrap(async (req, res) => {
  const u = (await q('select id,email from users where id=$1', [req.uid])).rows[0];
  if (!u) return res.status(401).json({ error: 'Login karo' });
  res.json({ ...u, profile: (await q('select * from profiles where user_id=$1', [req.uid])).rows[0] || null });
}));

app.put('/api/profile', auth, wrap(async (req, res) => {
  const b = req.body, photo = String(b.photo || '');
  const p = {
    name: str(b.name, 40), age: parseInt(b.age, 10), gender: b.gender, state: str(b.state, 40),
    city: str(b.city, 40), area: str(b.area, 50), style: b.style, level: b.level, want: b.want,
    venue: str(b.venue, 60), bio: str(b.bio, 160)
  };
  if (!(p.age >= 18 && p.age <= 80)) return res.status(400).json({ error: 'Sirf 18+ log profile bana sakte hain' });
  if (!p.name || !p.city || !p.state) return res.status(400).json({ error: 'Naam, state aur city zaroori hain' });
  for (const k of Object.keys(ENUM)) if (!ENUM[k].includes(p[k])) return res.status(400).json({ error: k + ' galat hai' });
  if (photo && (!/^data:image\/jpeg;base64,[A-Za-z0-9+\/=]+$/.test(photo) || photo.length > 70000)) return res.status(400).json({ error: 'Photo sahi nahi hai' });
  await q(`insert into profiles(user_id,name,age,gender,state,city,area,style,level,want,venue,bio,photo,updated)
    values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)
    on conflict(user_id) do update set name=excluded.name,age=excluded.age,gender=excluded.gender,state=excluded.state,
    city=excluded.city,area=excluded.area,style=excluded.style,level=excluded.level,want=excluded.want,
    venue=excluded.venue,bio=excluded.bio,photo=excluded.photo,updated=excluded.updated`,
    [req.uid, p.name, p.age, p.gender, p.state, p.city, p.area, p.style, p.level, p.want, p.venue, p.bio, photo, Date.now()]);
  res.json({ ok: true });
}));

app.get('/api/profiles', auth, wrap(async (req, res) => {
  const f = req.query, p = [req.uid], w = ['user_id != $1', NOT_BLOCKED];
  const add = (sql, v) => { p.push(v); w.push(sql.replace('?', '$' + p.length)); };
  if (f.q) add("(lower(city) like ? or lower(coalesce(area,'')) like ?)".replace('?', '$' + (p.length + 1)), '%' + str(f.q, 40).toLowerCase() + '%');
  if (f.state) add('state = ?', str(f.state, 40));
  for (const k of ['gender', 'style', 'level']) if (ENUM[k].includes(f[k])) add(k + ' = ?', f[k]);
  const a1 = parseInt(f.a1, 10), a2 = parseInt(f.a2, 10);
  if (a1) add('age >= ?', a1);
  if (a2) add('age <= ?', a2);
  let order = 'updated desc';
  if (f.sort === 'near') {
    const m = (await q('select city,state from profiles where user_id=$1', [req.uid])).rows[0];
    if (m) { p.push(String(m.city).toLowerCase()); const c = p.length; p.push(m.state); order = `(lower(city)=$${c}) desc, (state=$${p.length}) desc, updated desc`; }
  }
  const page = Math.max(0, parseInt(f.page, 10) || 0);
  res.json((await q(`select * from profiles where ${w.join(' and ')} order by ${order} limit 24 offset ${page * 24}`, p)).rows);
}));

app.get('/api/profile/:id', auth, wrap(async (req, res) => {
  const id = parseInt(req.params.id, 10);
  if (!id || await isBlocked(req.uid, id)) return res.status(404).json({ error: 'Profile nahi mila' });
  const r = (await q('select * from profiles where user_id=$1', [id])).rows[0];
  r ? res.json(r) : res.status(404).json({ error: 'Profile nahi mila' });
}));

app.get('/api/unread', auth, wrap(async (req, res) => {
  const r = await q(`select count(*) n from messages where to_id=$1 and not seen and from_id not in
    (select blocked from blocks where blocker=$1) and from_id not in (select blocker from blocks where blocked=$1)`, [req.uid]);
  res.json({ n: r.rows[0].n });
}));

app.get('/api/threads', auth, wrap(async (req, res) => {
  res.json((await q(`select t.peer, max(t.sent_at) as last_at, sum(t.unread) as unread, p.name, p.photo from
    (select case when from_id=$1 then to_id else from_id end as peer, sent_at,
      (case when to_id=$1 and not seen then 1 else 0 end) as unread from messages where from_id=$1 or to_id=$1) t
    left join profiles p on p.user_id = t.peer
    where t.peer not in (select blocked from blocks where blocker=$1) and t.peer not in (select blocker from blocks where blocked=$1)
    group by t.peer, p.name, p.photo order by last_at desc`, [req.uid])).rows);
}));

app.get('/api/messages/:peer', auth, wrap(async (req, res) => {
  const p = parseInt(req.params.peer, 10);
  if (!p || await isBlocked(req.uid, p)) return res.json([]);
  await q('update messages set seen=true where from_id=$2 and to_id=$1 and not seen', [req.uid, p]);
  res.json((await q(`select id,from_id,text,sent_at from messages
    where (from_id=$1 and to_id=$2) or (from_id=$2 and to_id=$1) order by sent_at limit 500`, [req.uid, p])).rows);
}));

app.post('/api/messages/:peer', auth, wrap(async (req, res) => {
  const p = parseInt(req.params.peer, 10), text = str(req.body.text, 500);
  if (!p || !text || p === req.uid) return res.status(400).json({ error: 'Message khaali hai' });
  const has = async id => (await q('select 1 from profiles where user_id=$1', [id])).rowCount > 0;
  if (!(await has(req.uid))) return res.status(400).json({ error: 'Pehle apna profile banao' });
  if (!(await has(p))) return res.status(404).json({ error: 'User nahi mila' });
  if (await isBlocked(req.uid, p)) return res.status(403).json({ error: 'Is user ko message nahi bhej sakte' });
  await q('insert into messages(from_id,to_id,text,sent_at) values($1,$2,$3,$4)', [req.uid, p, text, Date.now()]);
  res.json({ ok: true });
}));

app.post('/api/block/:id', auth, wrap(async (req, res) => {
  const id = parseInt(req.params.id, 10);
  if (!id || id === req.uid) return res.status(400).json({ error: 'Galat user' });
  await q('insert into blocks(blocker,blocked) values($1,$2) on conflict do nothing', [req.uid, id]);
  res.json({ ok: true });
}));

app.post('/api/report/:id', auth, wrap(async (req, res) => {
  const id = parseInt(req.params.id, 10), reason = str(req.body.reason, 300);
  if (!id || id === req.uid || !reason) return res.status(400).json({ error: 'Reason likho' });
  await q('insert into reports(reporter,reported,reason,sent_at) values($1,$2,$3,$4)', [req.uid, id, reason, Date.now()]);
  res.json({ ok: true });
}));

const checkPw = async (uid, pw) => {
  const u = (await q('select pass from users where id=$1', [uid])).rows[0];
  return !!u && bcrypt.compareSync(String(pw || ''), u.pass);
};
app.put('/api/password', auth, wrap(async (req, res) => {
  const n = String(req.body.new || '');
  if (!(await checkPw(req.uid, req.body.old))) return res.status(400).json({ error: 'Purana password galat hai' });
  if (n.length < 8 || n.length > 72) return res.status(400).json({ error: 'Naya password 8+ characters ka ho' });
  await q('update users set pass=$1 where id=$2', [bcrypt.hashSync(n, 10), req.uid]);
  res.json({ ok: true });
}));

app.delete('/api/account', auth, wrap(async (req, res) => {
  if (!(await checkPw(req.uid, req.body.password))) return res.status(400).json({ error: 'Password galat hai' });
  const id = req.uid;
  await q('delete from messages where from_id=$1 or to_id=$1', [id]);
  await q('delete from blocks where blocker=$1 or blocked=$1', [id]);
  await q('delete from reports where reporter=$1', [id]);
  await q('delete from profiles where user_id=$1', [id]);
  await q('delete from users where id=$1', [id]);
  res.json({ ok: true });
}));

app.use((err, req, res, next) => { console.error(err); res.status(500).json({ error: 'Server error' }); });

module.exports = app;
if (require.main === module) app.listen(process.env.PORT || 3000, () => console.log('Garba Jodi API chal raha hai'));
