// Same project mein frontend aur backend hain, isliye URL ki zaroorat nahi.
window.GARBA_API = '';
