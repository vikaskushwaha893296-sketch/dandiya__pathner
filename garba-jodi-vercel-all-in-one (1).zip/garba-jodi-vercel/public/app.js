(function () {
  var API = (window.GARBA_API || '').replace(/\/$/, '');
  var $ = function (i) { return document.getElementById(i); };
  var S = { me: null, profile: null, list: [], page: 0, more: false, threads: [], msgs: [], view: 'home', peer: null, tk: localStorage.getItem('gj_token'), photo: '', mode: 'login', timer: null, ft: null };
  var STATES = 'Andhra Pradesh,Bihar,Chhattisgarh,Delhi,Goa,Gujarat,Haryana,Himachal Pradesh,Jharkhand,Karnataka,Kerala,Madhya Pradesh,Maharashtra,Odisha,Punjab,Rajasthan,Tamil Nadu,Telangana,Uttar Pradesh,Uttarakhand,West Bengal,Other'.split(',');
  var FIELDS = ['name', 'age', 'gender', 'state', 'city', 'area', 'style', 'level', 'want', 'venue', 'bio'];
  function esc(s) { var d = document.createElement('div'); d.textContent = s == null ? '' : s; return d.innerHTML.replace(/"/g, '&quot;'); }
  function ini(n) { return (n || '?').trim().charAt(0).toUpperCase(); }
  function hue(n) { var h = 0; for (var i = 0; i < (n || '').length; i++) h = (h * 31 + n.charCodeAt(i)) % 360; return h; }
  function av(p, cls) {
    if (p && p.photo) return '<img class="ph ' + (cls || '') + '" alt="" src="' + esc(p.photo) + '">';
    return '<div class="ph ' + (cls || '') + '" style="background:hsl(' + hue(p && p.name) + ',55%,45%)">' + ini(p && p.name) + '</div>';
  }
  function toast(m) { var t = $('toast'); t.textContent = m; t.hidden = false; clearTimeout(S.ft); S.ft = setTimeout(function () { t.hidden = true; }, 2600); }
  STATES.forEach(function (s) { ['fst', 'fstate'].forEach(function (i) { var o = document.createElement('option'); o.textContent = s; $(i).appendChild(o); }); });

  async function api(path, o) {
    o = o || {};
    var h = { 'Content-Type': 'application/json' };
    if (S.tk) h.Authorization = 'Bearer ' + S.tk;
    var r = await fetch(API + '/api' + path, { method: o.method || 'GET', headers: h, body: o.body ? JSON.stringify(o.body) : undefined });
    var j = await r.json().catch(function () { return {}; });
    if (!r.ok) { if (r.status === 401 && S.tk) logout(); throw new Error(j.error || 'Kuch galat ho gaya'); }
    return j;
  }
  function logout() {
    localStorage.removeItem('gj_token'); clearInterval(S.timer);
    S.tk = null; S.me = null; S.profile = null; S.list = []; S.threads = []; S.msgs = []; S.peer = null; S.view = 'home';
    render();
  }
  function openM(id) { $(id).hidden = false; }
  function closeM() { ['m-auth', 'm-prof', 'm-safe'].forEach(function (i) { $(i).hidden = true; }); }
  function authMode(m) {
    S.mode = m; $('t-login').className = m === 'login' ? 'on' : ''; $('t-register').className = m === 'register' ? 'on' : '';
    $('l18').hidden = m !== 'register'; $('go').textContent = m === 'login' ? 'Login' : 'Account banao'; $('lerr').textContent = '';
  }
  async function doAuth() {
    $('lerr').textContent = '';
    if (S.mode === 'register' && !$('c18r').checked) { $('lerr').textContent = 'Sirf 18+ log join kar sakte hain.'; return; }
    try {
      var j = await api('/' + S.mode, { method: 'POST', body: { email: $('lemail').value, password: $('lpass').value } });
      S.tk = j.token; localStorage.setItem('gj_token', j.token); $('lpass').value = ''; closeM();
      await boot(S.mode === 'register');
    } catch (e) { $('lerr').textContent = e.message; }
  }
  async function boot(isNew) {
    if (!S.tk) return render();
    try {
      var me = await api('/me'); S.me = { id: me.id, email: me.email }; S.profile = me.profile;
      clearInterval(S.timer); S.timer = setInterval(tick, 5000); tick();
      if (!S.profile) { setView('edit'); toast('Pehle apna profile banao'); } else setView(isNew ? 'edit' : 'browse');
    } catch (e) { render(); }
  }
  async function tick() {
    if (!S.me || document.hidden) return;
    try {
      var u = await api('/unread'); var b = $('bd'); b.textContent = u.n; b.hidden = !u.n;
      if (S.view === 'chat') { S.threads = await api('/threads'); if (S.peer) S.msgs = await api('/messages/' + S.peer); rChat(); }
    } catch (e) {}
  }
  function setView(v, peer) {
    if (!S.me && v !== 'home') { authMode('login'); openM('m-auth'); return; }
    S.view = v; $('menu').hidden = true; closeM();
    if (peer) S.peer = peer;
    if (v === 'edit') {
      var f = $('f'), p = S.profile || {}; FIELDS.forEach(function (k) { f.elements[k].value = p[k] == null ? '' : p[k]; });
      S.photo = p.photo || ''; $('c18').checked = !!S.profile; $('st').textContent = ''; rPhoto();
    }
    if (v === 'browse') loadList(true);
    if (v === 'chat') { S.msgs = []; tick(); }
    render(); window.scrollTo(0, 0);
  }
  function render() {
    var nm = (S.profile && S.profile.name) || (S.me && S.me.email) || '';
    $('lg').hidden = !!S.me; $('av').hidden = !S.me;
    $('av').innerHTML = S.me ? (S.profile && S.profile.photo ? '<img alt="" src="' + esc(S.profile.photo) + '">' : ini(nm)) : '';
    $('menu').innerHTML = S.me ? '<div class="mn">' + esc(nm) + '<div class="sm">' + esc(S.me.email) + '</div></div><hr><button data-v="browse">Partners dhundo</button><button data-v="chat">Messages</button><button data-v="edit">Mera profile</button><button data-v="settings">Settings</button><button data-a="safe">Safety tips</button><hr><button data-a="out">Logout</button>' : '';
    ['home', 'browse', 'edit', 'chat', 'settings'].forEach(function (v) { $('v-' + v).hidden = S.view !== v; });
    if (S.view === 'browse') rBrowse(); else if (S.view === 'chat') rChat();
  }
  function rPhoto() { $('pp').innerHTML = av({ name: $('f').elements.name.value || '?', photo: S.photo }, 'lg'); }
  function qs() {
    var m = { q: $('q').value.trim(), state: $('fst').value, gender: $('fg').value, style: $('fs').value, level: $('fl').value, a1: $('a1').value, a2: $('a2').value, sort: $('so').value, page: S.page };
    return Object.keys(m).filter(function (k) { return m[k] !== '' && m[k] !== 0; }).map(function (k) { return k + '=' + encodeURIComponent(m[k]); }).join('&');
  }
  async function loadList(reset) {
    if (reset) S.page = 0;
    try {
      var r = await api('/profiles?' + qs());
      S.list = reset ? r : S.list.concat(r); S.more = r.length === 24; rBrowse();
    } catch (e) { toast(e.message); }
  }
  function rBrowse() {
    $('nb').hidden = !S.me || !!S.profile; $('more').hidden = !S.more;
    $('list').innerHTML = S.list.length ? S.list.map(function (p) {
      return '<div class="c" data-a="view" data-id="' + p.user_id + '"><div class="hd">' + av(p) + '<div><h3>' + esc(p.name) + ', ' + esc(p.age) + '</h3><div class="sub">' + esc(p.gender) + ' · 📍 ' + esc(p.area ? p.area + ', ' : '') + esc(p.city) + ', ' + esc(p.state) + '</div></div></div>' +
        '<div class="tags"><span class="tag">' + esc(p.style) + '</span><span class="tag">' + esc(p.level) + '</span></div>' +
        '<p>Chahiye: ' + esc(p.want) + (p.venue ? ' · ' + esc(p.venue) : '') + '</p>' + (p.bio ? '<p>' + esc(p.bio) + '</p>' : '') +
        '<button class="btn p s" data-a="msg" data-id="' + p.user_id + '">💬 Message</button></div>';
    }).join('') : '<div class="empty">Koi profile nahi mila. Filters badal ke dekho ya pehla profile aap banao! 💃🕺</div>';
  }
  async function openProfile(id) {
    var p = S.list.filter(function (x) { return x.user_id === id; })[0];
    if (!p) { try { p = await api('/profile/' + id); } catch (e) { return toast(e.message); } }
    $('pm').innerHTML = av(p, 'lg') + '<h2 style="margin:8px 0 0">' + esc(p.name) + ', ' + esc(p.age) + '</h2><div class="sub">' + esc(p.gender) + ' · 📍 ' + esc(p.area ? p.area + ', ' : '') + esc(p.city) + ', ' + esc(p.state) + '</div>' +
      '<div class="tags" style="margin-top:8px"><span class="tag">' + esc(p.style) + '</span><span class="tag">' + esc(p.level) + '</span></div>' +
      '<p>Chahiye: ' + esc(p.want) + (p.venue ? ' · ' + esc(p.venue) : '') + '</p>' + (p.bio ? '<p>' + esc(p.bio) + '</p>' : '') +
      '<div class="acts"><button class="btn p" data-a="msg" data-id="' + p.user_id + '">💬 Message</button></div>' +
      '<div class="acts"><button class="lnk" data-a="report" data-id="' + p.user_id + '">Report</button><button class="lnk" data-a="block" data-id="' + p.user_id + '">Block</button></div>';
    openM('m-prof');
  }
  function pinfo(id) {
    var t = S.threads.filter(function (x) { return x.peer === id; })[0], p = S.list.filter(function (x) { return x.user_id === id; })[0];
    return t ? { name: t.name, photo: t.photo } : (p || { name: 'User' });
  }
  function rChat() {
    if (!S.me) return;
    var th = S.threads.slice();
    if (S.peer && !th.some(function (t) { return t.peer === S.peer; })) { var i = pinfo(S.peer); th.unshift({ peer: S.peer, name: i.name, photo: i.photo, unread: 0 }); }
    $('cl').innerHTML = th.length ? th.map(function (t) {
      return '<button data-a="open" data-id="' + t.peer + '" class="' + (t.peer === S.peer ? 'on' : '') + '">' + av(t) + '<span>' + esc(t.name || 'User') + '</span>' + (t.unread ? '<i class="badge">' + t.unread + '</i>' : '') + '</button>';
    }).join('') : '<div class="sub" style="padding:14px">Abhi koi chat nahi. Partners dhundo mein kisi profile par Message dabao.</div>';
    $('ch').innerHTML = S.peer ? '<span style="cursor:pointer" data-a="view" data-id="' + S.peer + '">' + esc(pinfo(S.peer).name || 'User') + '</span>' : 'Koi chat chuniye';
    var box = $('cm'), n = box.childElementCount;
    box.innerHTML = (S.peer ? S.msgs : []).map(function (m) { return '<div class="b' + (m.from_id === S.me.id ? ' me' : '') + '">' + esc(m.text) + '</div>'; }).join('');
    if (box.childElementCount !== n) box.scrollTop = 1e9;
  }
  document.addEventListener('click', async function (e) {
    var t = e.target.closest('[data-v],[data-a]');
    if (e.target.classList.contains('modal')) return closeM();
    if (!t) { $('menu').hidden = true; return; }
    if (t.dataset.v) return setView(t.dataset.v);
    var a = t.dataset.a, id = +t.dataset.id;
    if (a === 'menu') $('menu').hidden = !$('menu').hidden;
    else if (a === 'auth') { authMode(t.id === 'lg' ? 'login' : 'register'); openM('m-auth'); }
    else if (a === 'tab') authMode(t.dataset.t);
    else if (a === 'go') doAuth();
    else if (a === 'close') closeM();
    else if (a === 'safe') { $('menu').hidden = true; openM('m-safe'); }
    else if (a === 'more') { S.page++; loadList(false); }
    else if (a === 'view') { if (e.target.closest('[data-a="msg"]')) return; openProfile(id); }
    else if (a === 'msg' || a === 'open') { e.stopPropagation(); S.msgs = []; S.view = 'chat'; setView('chat', id); }
    else if (a === 'rmphoto') { S.photo = ''; rPhoto(); }
    else if (a === 'out') logout();
    else if (a === 'report') {
      var why = prompt('Report ka reason likho:'); if (!why) return;
      try { await api('/report/' + id, { method: 'POST', body: { reason: why } }); toast('Report bhej di gayi. Shukriya.'); } catch (er) { toast(er.message); }
    } else if (a === 'block') {
      if (!confirm('Is user ko block karein? Aap dono ek doosre ko nahi dekh paoge.')) return;
      try {
        await api('/block/' + id, { method: 'POST' }); closeM();
        S.list = S.list.filter(function (x) { return x.user_id !== id; }); if (S.peer === id) S.peer = null;
        toast('User block ho gaya.'); tick(); render();
      } catch (er) { toast(er.message); }
    }
  });
  ['q', 'fst', 'fg', 'fs', 'fl', 'a1', 'a2', 'so'].forEach(function (i) {
    $(i).addEventListener('input', function () { clearTimeout(S.ft2); S.ft2 = setTimeout(function () { loadList(true); }, 350); });
  });
  $('f').elements.name.addEventListener('input', rPhoto);
  $('pf').addEventListener('change', function () {
    var file = this.files[0]; if (!file) return;
    var img = new Image(), url = URL.createObjectURL(file);
    img.onload = function () {
      var c = document.createElement('canvas'), n = 200, s = Math.min(img.width, img.height);
      c.width = c.height = n; c.getContext('2d').drawImage(img, (img.width - s) / 2, (img.height - s) / 2, s, s, 0, 0, n, n);
      S.photo = c.toDataURL('image/jpeg', 0.72); URL.revokeObjectURL(url); rPhoto();
    };
    img.onerror = function () { toast('Photo load nahi hui'); };
    img.src = url;
  });
  $('f').addEventListener('submit', async function (e) {
    e.preventDefault();
    var o = {}; new FormData(this).forEach(function (v, k) { if (FIELDS.indexOf(k) > -1) o[k] = String(v).trim(); });
    o.age = +o.age; o.photo = S.photo;
    try { await api('/profile', { method: 'PUT', body: o }); S.profile = Object.assign({ user_id: S.me.id }, o); toast('Profile save ho gaya ✅'); setView('browse'); }
    catch (err) { $('st').textContent = err.message; }
  });
  $('cf').addEventListener('submit', async function (e) {
    e.preventDefault();
    var tx = $('ci').value.trim(); if (!tx || !S.peer) return;
    try { await api('/messages/' + S.peer, { method: 'POST', body: { text: tx } }); $('ci').value = ''; tick(); }
    catch (err) { toast(err.message); }
  });
  $('fpw').addEventListener('submit', async function (e) {
    e.preventDefault();
    try { await api('/password', { method: 'PUT', body: { old: $('op').value, new: $('np').value } }); this.reset(); toast('Password badal gaya ✅'); }
    catch (err) { toast(err.message); }
  });
  $('fdel').addEventListener('submit', async function (e) {
    e.preventDefault();
    if (!confirm('Pakka? Account hamesha ke liye delete ho jayega.')) return;
    try { await api('/account', { method: 'DELETE', body: { password: $('dp').value } }); this.reset(); logout(); toast('Account delete ho gaya.'); }
    catch (err) { toast(err.message); }
  });
  $('lpass').addEventListener('keydown', function (e) { if (e.key === 'Enter') doAuth(); });
  render(); boot();
})();
